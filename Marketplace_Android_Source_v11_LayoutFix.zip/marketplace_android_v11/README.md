Marketplace Android v11 Layout Fix

- Fixed-size native toolbar buttons and correctly measured title.
- Mobile WebView viewport instead of desktop-width viewport.
- Removed forced viewport meta rewriting and global box-sizing overrides.
- Preserves v9 dark inversion and two-column Marketplace listing layout.
- Build with existing GitHub Actions workflow.

Experimental: Facebook may change its responsive layout.
