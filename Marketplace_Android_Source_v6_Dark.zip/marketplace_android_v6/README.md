Marketplace v6: dark-mode inversion with restored images, original Facebook grid. GitHub Actions workflow included. Experimental: Facebook may alter page styles.
