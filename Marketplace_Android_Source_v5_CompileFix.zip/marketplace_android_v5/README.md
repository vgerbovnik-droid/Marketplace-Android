Marketplace v1.5: исправлена ошибка Java illegal escape character в CSS/JS-теме. Архив исходников для универсального GitHub Actions workflow.
