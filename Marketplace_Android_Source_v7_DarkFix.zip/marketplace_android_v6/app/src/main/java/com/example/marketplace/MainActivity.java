package com.example.marketplace;

import android.app.Activity;
import android.os.Bundle;
import android.content.res.Configuration;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.facebook.com/marketplace/";
    private WebView web;
    private ProgressBar progress;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Ask Android WebView for a dark color scheme.
        Configuration config = new Configuration(getResources().getConfiguration());
        config.uiMode = (config.uiMode & ~Configuration.UI_MODE_NIGHT_MASK) | Configuration.UI_MODE_NIGHT_YES;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,18));
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Color.rgb(28,28,30));
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Marketplace"); title.setTextColor(Color.WHITE); title.setTextSize(19);
        title.setPadding(18,12,12,12);
        bar.addView(title,new LinearLayout.LayoutParams(0,56,1));
        Button home = button("⌂"); home.setOnClickListener(v -> web.loadUrl(HOME)); bar.addView(home);
        Button refresh = button("↻"); refresh.setOnClickListener(v -> web.reload()); bar.addView(refresh);
        root.addView(bar);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        root.addView(progress,new LinearLayout.LayoutParams(-1,4));
        web = new WebView(this);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        web.setHorizontalScrollBarEnabled(false);
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            s.setAlgorithmicDarkeningAllowed(true);
        } else if (android.os.Build.VERSION.SDK_INT >= 29) {
            s.setForceDark(WebSettings.FORCE_DARK_ON);
        }
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int p) {progress.setProgress(p);progress.setVisibility(p==100?View.GONE:View.VISIBLE);}
        });
        web.setBackgroundColor(Color.rgb(18,18,18));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url != null && (url.contains("facebook.com") || url.contains("fb.com"))) applyTheme(view);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl(); String scheme=u.getScheme();
                if (scheme==null) return true;
                if (scheme.equals("https") || scheme.equals("http")) {
                    String host=u.getHost();
                    if(host!=null && (host.equals("facebook.com") || host.endsWith(".facebook.com") || host.equals("fb.com") || host.endsWith(".fb.com") || host.equals("messenger.com") || host.endsWith(".messenger.com"))) return false;
                    try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                    return true;
                }
                try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                return true;
            }
        });
        if(state!=null) web.restoreState(state); else web.loadUrl(HOME);
    }
    private void applyTheme(WebView view) {
        String js = """
          (function(){
            if (window.__marketplaceDarkV7) { window.__marketplaceDarkV7(); return; }
            var pending=false, processing=false;
            function isLight(c){
              var m=/rgba?\\(\\s*(\\d+)[, ]+\\s*(\\d+)[, ]+\\s*(\\d+)(?:[, /]+([\\d.]+))?/.exec(c||'');
              if(!m) return false;
              var a=m[4]===undefined?1:parseFloat(m[4]);
              return a>.85 && (+m[1]*.2126 + +m[2]*.7152 + +m[3]*.0722)>155;
            }
            function isDark(c){
              var m=/rgba?\\(\\s*(\\d+)[, ]+\\s*(\\d+)[, ]+\\s*(\\d+)/.exec(c||'');
              return !!m && (+m[1]*.2126 + +m[2]*.7152 + +m[3]*.0722)<115;
            }
            function paint(){
              if(processing)return;
              processing=true;
              try {
                document.documentElement.style.setProperty('background-color','#121212','important');
                if(document.body) document.body.style.setProperty('background-color','#121212','important');
                var nodes=document.querySelectorAll('body, body *');
                for(var i=0;i<nodes.length && i<8500;i++){
                  var el=nodes[i];
                  if(el.closest('svg,canvas,video,picture') || /^(IMG|SVG|CANVAS|VIDEO|SCRIPT|STYLE|NOSCRIPT)$/.test(el.tagName))continue;
                  var cs=getComputedStyle(el);
                  if(isLight(cs.backgroundColor) && cs.backgroundImage==='none'){
                    el.style.setProperty('background-color',el.matches('input,textarea,button,[role="button"]')?'#303035':'#1c1c1e','important');
                  }
                  if(isDark(cs.color)) el.style.setProperty('color','#f5f5f7','important');
                  if(isLight(cs.borderTopColor) && cs.borderTopStyle!=='none')el.style.setProperty('border-top-color','#404044','important');
                  if(isLight(cs.borderBottomColor) && cs.borderBottomStyle!=='none')el.style.setProperty('border-bottom-color','#404044','important');
                }
              } finally {processing=false;}
            }
            function schedule(){if(pending)return;pending=true;setTimeout(function(){pending=false;paint();},250);}
            window.__marketplaceDarkV7=schedule;
            var style=document.createElement('style');
            style.textContent='html,body{background:#121212!important;color-scheme:dark!important}input,textarea{caret-color:white!important}img,video,canvas{filter:none!important}';
            (document.head||document.documentElement).appendChild(style);
            new MutationObserver(function(m){
              if(processing)return;
              for(var i=0;i<m.length;i++)if(m[i].type==='childList' && m[i].addedNodes.length){schedule();break;}
            }).observe(document.documentElement,{subtree:true,childList:true});
            schedule();setTimeout(schedule,1200);setTimeout(schedule,3500);
          })();
        """;
        view.evaluateJavascript(js, null);
    }
    private Button button(String text) {Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);b.setTextSize(23);return b;}
    @Override public void onBackPressed() {if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
}
