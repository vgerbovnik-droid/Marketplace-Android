# Marketplace Android v14 — WebView Fit

Restores the correct mobile viewport scaling: `setUseWideViewPort(true)`, `setLoadWithOverviewMode(true)`, and automatic initial scale (`setInitialScale(0)`). Keeps the v13 dark-mode toggle and original listing grid. No viewport meta injection or forced grid widths.

Upload this source ZIP to the GitHub repository using the existing universal build workflow. This change is not yet device-tested.
