package com.example.marketplace;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.facebook.com/marketplace/";
    private WebView web;
    private ProgressBar progress;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,18));
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Color.rgb(28,28,30));
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Marketplace"); title.setTextColor(Color.WHITE); title.setTextSize(19);
        title.setPadding(18,12,12,12);
        bar.addView(title,new LinearLayout.LayoutParams(0,56,1));
        Button home = button("⌂"); home.setOnClickListener(v -> web.loadUrl(HOME)); bar.addView(home);
        Button refresh = button("↻"); refresh.setOnClickListener(v -> web.reload()); bar.addView(refresh);
        root.addView(bar);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        root.addView(progress,new LinearLayout.LayoutParams(-1,4));
        web = new WebView(this);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        web.setHorizontalScrollBarEnabled(false);
        if (android.os.Build.VERSION.SDK_INT >= 33) s.setAlgorithmicDarkeningAllowed(false);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int p) {progress.setProgress(p);progress.setVisibility(p==100?View.GONE:View.VISIBLE);}
        });
        web.setBackgroundColor(Color.rgb(18,18,18));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url != null && (url.contains("facebook.com") || url.contains("fb.com"))) applyTheme(view);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl(); String scheme=u.getScheme();
                if (scheme==null) return true;
                if (scheme.equals("https") || scheme.equals("http")) {
                    String host=u.getHost();
                    if(host!=null && (host.equals("facebook.com") || host.endsWith(".facebook.com") || host.equals("fb.com") || host.endsWith(".fb.com") || host.equals("messenger.com") || host.endsWith(".messenger.com"))) return false;
                    try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                    return true;
                }
                try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                return true;
            }
        });
        if(state!=null) web.restoreState(state); else web.loadUrl(HOME);
    }
    private void applyTheme(WebView view) {
        // The Facebook DOM is not stable. Do not force white text onto white backgrounds.
        // Convert light surfaces and dark text together, leaving photos and brand colors alone.
        String js = """
          (function(){
            if (window.__marketplaceDarkV4) { window.__marketplaceDarkV4(); return; }
            var style=document.createElement('style');
            style.textContent=`
              :root { color-scheme: dark !important; --web-wash:#141414 !important;
                --surface-background:#141414 !important; --card-background:#242424 !important;
                --primary-text:#f7f7f7 !important; --secondary-text:#c0c0c0 !important; }
              html,body { background:#141414 !important; color:#f7f7f7 !important;
                width:100% !important; max-width:100% !important; overflow-x:hidden !important; }
              input,textarea,[role=searchbox] { background:#292929 !important;
                color:#fff !important; caret-color:#fff !important; }
              input::placeholder,textarea::placeholder { color:#bcbcbc !important; }
              img,video { max-width:100%; }
            `;
            (document.head||document.documentElement).appendChild(style);
            function rgb(v){ var m=(v||'').match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
              return m ? [Number(m[1]),Number(m[2]),Number(m[3])] : null; }
            function luminance(c){return c ? (c[0]*.2126+c[1]*.7152+c[2]*.0722) : 0;}
            function repaint(){
              var nodes=document.querySelectorAll('body, body *');
              // Cap work on long feeds; newly inserted nodes are processed in later passes.
              for(var i=0;i<Math.min(nodes.length,3500);i++){
                var el=nodes[i];
                if(el.closest('svg, picture') || /^(IMG|VIDEO|CANVAS|SVG|PATH)$/.test(el.tagName)) continue;
                var cs=getComputedStyle(el), bg=rgb(cs.backgroundColor), fg=rgb(cs.color);
                if(bg && luminance(bg)>225){
                  el.style.setProperty('background-color',el.matches('button,[role=button]')?'#303033':'#191919','important');
                }
                if(fg && luminance(fg)<115 && !el.closest('svg') && !el.matches('img')){
                  // Keep Facebook blue and other saturated action colors intact.
                  var saturation=Math.max.apply(null,fg)-Math.min.apply(null,fg);
                  if(saturation<65) el.style.setProperty('color','#f2f2f2','important');
                }
              }
              // Avoid forcing grid dimensions: Facebook controls its own responsive layout.
              document.documentElement.style.overflowX='hidden';
              document.body.style.overflowX='hidden';
            }
            var scheduled=false;
            function schedule(){if(scheduled)return;scheduled=true;setTimeout(function(){scheduled=false;repaint();},350);}
            window.__marketplaceDarkV4=schedule;
            new MutationObserver(schedule).observe(document.documentElement,{childList:true,subtree:true});
            repaint();
          })();
        """;
        view.evaluateJavascript(js, null);
    }
    private Button button(String text) {Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);b.setTextSize(23);return b;}
    @Override public void onBackPressed() {if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
}
