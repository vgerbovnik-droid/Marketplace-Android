plugins { id("com.android.application") }

android {
    namespace = "com.example.marketplace"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.marketplace"
        minSdk = 24
        targetSdk = 35
        versionCode = 4
        versionName = "1.4"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
