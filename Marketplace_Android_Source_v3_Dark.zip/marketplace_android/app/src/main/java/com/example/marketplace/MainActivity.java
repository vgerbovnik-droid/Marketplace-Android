package com.example.marketplace;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.facebook.com/marketplace/";
    private WebView web;
    private ProgressBar progress;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,18));
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Color.rgb(28,28,30));
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Marketplace"); title.setTextColor(Color.WHITE); title.setTextSize(19);
        title.setPadding(18,12,12,12);
        bar.addView(title,new LinearLayout.LayoutParams(0,56,1));
        Button home = button("⌂"); home.setOnClickListener(v -> web.loadUrl(HOME)); bar.addView(home);
        Button refresh = button("↻"); refresh.setOnClickListener(v -> web.reload()); bar.addView(refresh);
        root.addView(bar);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        root.addView(progress,new LinearLayout.LayoutParams(-1,4));
        web = new WebView(this);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        if (android.os.Build.VERSION.SDK_INT >= 33) s.setAlgorithmicDarkeningAllowed(false);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int p) {progress.setProgress(p);progress.setVisibility(p==100?View.GONE:View.VISIBLE);}
        });
        web.setBackgroundColor(Color.rgb(18,18,18));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url != null && (url.contains("facebook.com") || url.contains("fb.com"))) applyTheme(view);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl(); String scheme=u.getScheme();
                if (scheme==null) return true;
                if (scheme.equals("https") || scheme.equals("http")) {
                    String host=u.getHost();
                    if(host!=null && (host.equals("facebook.com") || host.endsWith(".facebook.com") || host.equals("fb.com") || host.endsWith(".fb.com") || host.equals("messenger.com") || host.endsWith(".messenger.com"))) return false;
                    try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                    return true;
                }
                try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                return true;
            }
        });
        if(state!=null) web.restoreState(state); else web.loadUrl(HOME);
    }
    private void applyTheme(WebView view) {
        // Site-specific visual overrides. Facebook may change its HTML at any time.
        String css = """
          :root { color-scheme: dark !important; --web-wash: #121212 !important; --surface-background: #121212 !important; --primary-text: #f5f5f5 !important; --secondary-text: #b7b7b7 !important; --card-background: #202124 !important; }
          html, body, main, [role=main], [role=feed] { background-color: #121212 !important; color: #f5f5f5 !important; }
          h1,h2,h3,h4,h5,h6,p,span,a,label,button,div[role=button] { color: #f5f5f5; }
          input,textarea,[role=searchbox] { background-color: #292a2d !important; color: #fff !important; border-color: #454545 !important; }
          input::placeholder,textarea::placeholder { color: #bbb !important; }
          [role=dialog], [role=menu], [role=listbox] { background-color: #202124 !important; color: #fff !important; }
          /* Marketplace listing rows: two equal columns with consistent card widths. */
          a[href*='/marketplace/item/'] { min-width: 0 !important; max-width: 100% !important; overflow: hidden !important; }
          a[href*='/marketplace/item/'] img { width: 100% !important; aspect-ratio: 1 / 1 !important; object-fit: cover !important; display: block !important; }
          a[href*='/marketplace/item/'] span { overflow-wrap: anywhere; }
          """;
        String js = "(function(){try{var id='marketplace-v3-dark-style';var s=document.getElementById(id);if(!s){s=document.createElement('style');s.id=id;(document.head||document.documentElement).appendChild(s);}s.textContent=" + org.json.JSONObject.quote(css) + ";document.documentElement.style.colorScheme='dark';}catch(e){}})();";
        view.evaluateJavascript(js, null);
    }
    private Button button(String text) {Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);b.setTextSize(23);return b;}
    @Override public void onBackPressed() {if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
}
