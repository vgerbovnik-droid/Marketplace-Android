Marketplace v8 DarkStable

Android WebView for Facebook Marketplace. Uses DOM-based dark styling after page load, preserves original listing layout. Theme is best-effort because Facebook may change its HTML/CSS.
