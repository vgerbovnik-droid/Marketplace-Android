package com.example.marketplace;

import android.app.Activity;
import android.os.Bundle;
import android.content.res.Configuration;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.facebook.com/marketplace/";
    private WebView web;
    private ProgressBar progress;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Dark appearance is applied to the webpage separately.
        Configuration config = new Configuration(getResources().getConfiguration());
        config.uiMode = (config.uiMode & ~Configuration.UI_MODE_NIGHT_MASK) | Configuration.UI_MODE_NIGHT_YES;
        getResources().updateConfiguration(config, getResources().getDisplayMetrics());
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,18));
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Color.rgb(28,28,30));
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Marketplace"); title.setTextColor(Color.WHITE); title.setTextSize(19);
        title.setPadding(18,12,12,12);
        bar.addView(title,new LinearLayout.LayoutParams(0,56,1));
        Button home = button("⌂"); home.setOnClickListener(v -> web.loadUrl(HOME)); bar.addView(home);
        Button refresh = button("↻"); refresh.setOnClickListener(v -> web.reload()); bar.addView(refresh);
        root.addView(bar);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        root.addView(progress,new LinearLayout.LayoutParams(-1,4));
        web = new WebView(this);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        web.setHorizontalScrollBarEnabled(false);
        // Do not combine algorithmic darkening with custom CSS: it can cause flashes and inverted colors.
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int p) {progress.setProgress(p);progress.setVisibility(p==100?View.GONE:View.VISIBLE);}
        });
        web.setBackgroundColor(Color.rgb(18,18,18));
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url != null && (url.contains("facebook.com") || url.contains("fb.com"))) applyTheme(view);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl(); String scheme=u.getScheme();
                if (scheme==null) return true;
                if (scheme.equals("https") || scheme.equals("http")) {
                    String host=u.getHost();
                    if(host!=null && (host.equals("facebook.com") || host.endsWith(".facebook.com") || host.equals("fb.com") || host.endsWith(".fb.com") || host.equals("messenger.com") || host.endsWith(".messenger.com"))) return false;
                    try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                    return true;
                }
                try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                return true;
            }
        });
        if(state!=null) web.restoreState(state); else web.loadUrl(HOME);
    }
    private void applyTheme(WebView view) {
        // Facebook renders content asynchronously. Re-apply to newly inserted nodes
        // without modifying layout, image filters, or the dimensions of listing cards.
        String js = """
          (function(){
            if(window.__mpDarkV8){window.__mpDarkV8();return;}
            var queued=false;
            var dark='#1c1c1e', field='#303034', fg='#f5f5f7';
            function rgb(c){
              var m=/rgba?\\(\\s*(\\d+)[, ]+\\s*(\\d+)[, ]+\\s*(\\d+)(?:[, /]+([\\d.]+))?/.exec(c||'');
              if(!m)return null;
              return [+m[1],+m[2],+m[3],m[4]===undefined?1:+m[4]];
            }
            function luminance(v){return v[0]*.2126+v[1]*.7152+v[2]*.0722;}
            function patch(el){
              if(el.nodeType!==1 || /^(IMG|SVG|PATH|CANVAS|VIDEO|PICTURE|SCRIPT|STYLE|NOSCRIPT|IFRAME)$/.test(el.tagName))return;
              if(el.closest('svg,canvas,video,picture'))return;
              var cs=getComputedStyle(el);
              var bg=rgb(cs.backgroundColor), color=rgb(cs.color);
              if(bg && bg[3]>.9 && luminance(bg)>160 && cs.backgroundImage==='none'){
                el.style.setProperty('background-color',el.matches('input,textarea,button,[role="button"]')?field:dark,'important');
                bg=rgb(getComputedStyle(el).backgroundColor);
              }
              // Only recolor text against a known dark surface; preserve colors on pictures.
              if(color && luminance(color)<135 && (!bg || luminance(bg)<145)){
                el.style.setProperty('color',fg,'important');
              }
              if(el.matches('input,textarea')){
                el.style.setProperty('color',fg,'important');
                el.style.setProperty('caret-color',fg,'important');
              }
            }
            function paint(){
              queued=false;
              var doc=document.documentElement;
              doc.style.setProperty('background-color','#121212','important');
              if(document.body)document.body.style.setProperty('background-color','#121212','important');
              var nodes=document.querySelectorAll('body,body *');
              for(var i=0;i<nodes.length && i<12000;i++)patch(nodes[i]);
            }
            function schedule(){if(queued)return;queued=true;setTimeout(paint,100);}
            window.__mpDarkV8=schedule;
            var style=document.createElement('style');
            style.id='mp-dark-v8';
            style.textContent='html,body{background-color:#121212!important;color-scheme:dark!important} input,textarea{caret-color:#fff!important}';
            (document.head||document.documentElement).appendChild(style);
            new MutationObserver(function(records){
              for(var i=0;i<records.length;i++){
                if(records[i].type==='childList' && records[i].addedNodes.length){schedule();return;}
              }
            }).observe(document.documentElement,{subtree:true,childList:true});
            schedule();setTimeout(schedule,500);setTimeout(schedule,1500);setTimeout(schedule,4000);
          })();
        """;
        view.evaluateJavascript(js, null);
    }
    private Button button(String text) {Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);b.setTextSize(23);return b;}
    @Override public void onBackPressed() {if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
}
