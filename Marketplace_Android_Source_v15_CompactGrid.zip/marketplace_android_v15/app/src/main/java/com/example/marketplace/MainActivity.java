package com.example.marketplace;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.os.Build;
import android.view.WindowManager;
import android.view.View;
import android.view.ViewGroup;
import android.text.TextUtils;
import android.widget.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.facebook.com/marketplace/";
    private WebView web;
    private ProgressBar progress;
    private boolean darkEnabled = true;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        // Keep the app toolbar below the Android status bar instead of drawing behind it.
        getWindow().setStatusBarColor(Color.rgb(28,28,30));
        getWindow().setNavigationBarColor(Color.rgb(18,18,18));
        getWindow().getDecorView().setSystemUiVisibility(0);
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
        }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,18));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(Color.rgb(28,28,30));
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), 0, dp(8), 0);
        TextView title = new TextView(this);
        title.setText("Marketplace");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        title.setGravity(android.view.Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(52), 1f));
        Button home = button("⌂");
        home.setOnClickListener(v -> web.loadUrl(HOME));
        bar.addView(home, new LinearLayout.LayoutParams(dp(48), dp(48)));
        Button refresh = button("↻");
        refresh.setOnClickListener(v -> web.reload());
        bar.addView(refresh, new LinearLayout.LayoutParams(dp(48), dp(48)));
        Button theme = button("☾");
        theme.setOnClickListener(v -> { darkEnabled = !darkEnabled; applyTheme(web); applyCompactGrid(web); });
        bar.addView(theme, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(bar);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        root.addView(progress,new LinearLayout.LayoutParams(-1,4));
        web = new WebView(this);
        root.addView(web,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        root.setClipToPadding(false);
        root.setClipChildren(false);
        // Let WebView calculate the device scale from the page viewport.
        web.setInitialScale(0);
        web.setVerticalScrollBarEnabled(false);
        web.setBackgroundColor(Color.rgb(18,18,18));
        setContentView(root);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // Do not combine algorithmic darkening with custom CSS: it can cause flashes and inverted colors.
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int p) {progress.setProgress(p);progress.setVisibility(p==100?View.GONE:View.VISIBLE);}
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url != null && (url.contains("facebook.com") || url.contains("fb.com"))) { applyTheme(view); applyCompactGrid(view); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl(); String scheme=u.getScheme();
                if (scheme==null) return true;
                if (scheme.equals("https") || scheme.equals("http")) {
                    String host=u.getHost();
                    if(host!=null && (host.equals("facebook.com") || host.endsWith(".facebook.com") || host.equals("fb.com") || host.endsWith(".fb.com") || host.equals("messenger.com") || host.endsWith(".messenger.com"))) return false;
                    try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                    return true;
                }
                try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                return true;
            }
        });
        if(state!=null) web.restoreState(state); else web.loadUrl(HOME);
    }
    private void applyTheme(WebView view) {
        // Keep the proven dark filter, but do not modify Facebook's viewport,
        // document width or grid. Those rules caused clipping in v10-v12.
        String darkCss = "html{background:#121212!important;filter:invert(1) hue-rotate(180deg)!important;}" +
            "img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)!important;}";
        String lightCss = "html{filter:none!important;}img,video,canvas,picture{filter:none!important;}";
        String js = "(function(){" +
            "var s=document.getElementById('marketplace-v14-style');" +
            "if(!s){s=document.createElement('style');s.id='marketplace-v14-style';(document.head||document.documentElement).appendChild(s);}" +
            "s.textContent=" + jsonQuote(darkEnabled ? darkCss : lightCss) + ";" +
            "})();";
        view.evaluateJavascript(js, null);
    }
    private void applyCompactGrid(WebView view) {
        try (java.io.InputStream stream = getAssets().open("marketplace_compact.js")) {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[4096]; int n;
            while ((n = stream.read(buf)) != -1) out.write(buf, 0, n);
            view.evaluateJavascript(out.toString("UTF-8"), null);
        } catch (Exception ignored) { }
    }
    private static String jsonQuote(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }
    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setBackgroundColor(Color.TRANSPARENT); b.setTextSize(22);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(0, 0, 0, 0);
        return b;
    }
    @Override public void onBackPressed() {if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
}
