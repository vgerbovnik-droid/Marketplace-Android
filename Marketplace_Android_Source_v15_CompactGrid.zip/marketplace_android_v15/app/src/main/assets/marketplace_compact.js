(function(){
  // Apply to Marketplace listing anchors only. Do not change Facebook's viewport or grid columns.
  if (!location.pathname.includes('/marketplace')) return;
  if (!document.getElementById('mp-v15-compact-style')) {
    var style = document.createElement('style');
    style.id = 'mp-v15-compact-style';
    style.textContent = `
      [data-mp-compact="1"] { min-width:0!important; max-width:100%!important; overflow:hidden!important; }
      [data-mp-compact="1"] img { width:100%!important; height:clamp(90px, 14.5vh, 145px)!important; max-height:145px!important; object-fit:cover!important; }
      [data-mp-compact="1"] [data-mp-photo="1"] { height:clamp(90px, 14.5vh, 145px)!important; max-height:145px!important; overflow:hidden!important; }
      [data-mp-compact="1"] span { line-height:1.15!important; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }
  function apply(){
    var links=document.querySelectorAll('a[href*="/marketplace/item/"]');
    links.forEach(function(a){
      var img=a.querySelector('img');
      if(!img) return;
      a.setAttribute('data-mp-compact','1');
      // Image container is typically an immediate or second-level wrapper.
      var parent=img.parentElement;
      if(parent && parent!==a && a.contains(parent)) parent.setAttribute('data-mp-photo','1');
      // Keep the site's native two-column layout and responsive widths.
    });
  }
  apply();
  if(!window.__mpV15Observer){
    var scheduled=false;
    window.__mpV15Observer=new MutationObserver(function(){
      if(scheduled) return;
      scheduled=true;
      requestAnimationFrame(function(){scheduled=false;apply();});
    });
    window.__mpV15Observer.observe(document.documentElement,{childList:true,subtree:true});
  }
})();