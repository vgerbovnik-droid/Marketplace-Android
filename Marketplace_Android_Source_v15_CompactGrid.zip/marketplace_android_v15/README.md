# Marketplace Android v15 — Compact 2 × 3

Based on the working v14 WebView sizing and dark theme.

- Keeps the original Facebook Marketplace two-column grid.
- Limits listing image height to approximately 14.5% of viewport height (90–145 CSS pixels) to make three rows more compact.
- Reapplies formatting to dynamically loaded listings using MutationObserver.
- Does not modify the site viewport or WebView scale.

**Note:** Facebook controls the DOM, so six complete listings on one screen cannot be guaranteed for every device, page or login state. Other page elements (header, cookie dialog) take vertical space.

Build via the existing GitHub Actions workflow.
