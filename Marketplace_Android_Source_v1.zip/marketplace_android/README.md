# Marketplace Only (Android)

An independent, unofficial Android WebView launcher for https://www.facebook.com/marketplace/.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload **the contents** of this ZIP to the repository root (including `.github/workflows/build-apk.yml`). GitHub web upload may hide dot-folders; if necessary create the workflow file manually at that path.
3. Open **Actions → Build Marketplace APK → Run workflow**, or push to `main`.
4. After success, open the workflow run → **Artifacts → Marketplace-APK-v1**. Download and unzip to obtain `app-debug.apk`.

The build uses Gradle 8.9, Android Gradle Plugin 8.7.3 and Java 17.

## Limitations
Facebook may block login or some Marketplace features inside embedded WebView; this app cannot bypass Meta restrictions. Messenger links and external links may open in another app. Not affiliated with Meta.
