package com.example.marketplace;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.webkit.*;

public class MainActivity extends Activity {
    private static final String HOME = "https://www.facebook.com/marketplace/";
    private WebView web;
    private ProgressBar progress;
    private boolean darkEnabled = true;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(18,18,18));
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(Color.rgb(28,28,30));
        bar.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("Marketplace"); title.setTextColor(Color.WHITE); title.setTextSize(19);
        title.setPadding(18,12,12,12);
        bar.addView(title,new LinearLayout.LayoutParams(0,56,1));
        Button home = button("⌂"); home.setOnClickListener(v -> web.loadUrl(HOME)); bar.addView(home);
        Button refresh = button("↻"); refresh.setOnClickListener(v -> web.reload()); bar.addView(refresh);
        Button theme = button("☾");
        theme.setOnClickListener(v -> { darkEnabled = !darkEnabled; applyTheme(web); });
        bar.addView(theme);
        root.addView(bar);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        root.addView(progress,new LinearLayout.LayoutParams(-1,4));
        web = new WebView(this);
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        web.setHorizontalScrollBarEnabled(false);
        // Do not combine algorithmic darkening with custom CSS: it can cause flashes and inverted colors.
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int p) {progress.setProgress(p);progress.setVisibility(p==100?View.GONE:View.VISIBLE);}
        });
        web.setBackgroundColor(Color.WHITE);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view,url);
                if (url != null && (url.contains("facebook.com") || url.contains("fb.com"))) applyTheme(view);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u=request.getUrl(); String scheme=u.getScheme();
                if (scheme==null) return true;
                if (scheme.equals("https") || scheme.equals("http")) {
                    String host=u.getHost();
                    if(host!=null && (host.equals("facebook.com") || host.endsWith(".facebook.com") || host.equals("fb.com") || host.endsWith(".fb.com") || host.equals("messenger.com") || host.endsWith(".messenger.com"))) return false;
                    try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                    return true;
                }
                try {startActivity(new Intent(Intent.ACTION_VIEW,u));} catch(Exception ignored) {}
                return true;
            }
        });
        if(state!=null) web.restoreState(state); else web.loadUrl(HOME);
    }
    private void applyTheme(WebView view) {
        // One reversible filter for the entire page; do not recolor individual text nodes.
        // Undo the filter on media to preserve original listing photos.
        String js = "(function(){" +
            "var id='marketplace-v9-theme';" +
            "var st=document.getElementById(id);" +
            "if(!st){st=document.createElement('style');st.id=id;(document.head||document.documentElement).appendChild(st);}" +
            "st.textContent=" + (darkEnabled ?
                "'html{background:#121212!important;filter:invert(1) hue-rotate(180deg)!important;}img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)!important;}body{overflow-x:hidden!important;max-width:100vw!important;}'" :
                "'html{filter:none!important;}img,video,canvas,picture{filter:none!important;}body{overflow-x:hidden!important;max-width:100vw!important;}'") +
            ";})();";
        view.evaluateJavascript(js, null);
    }
    private Button button(String text) {Button b=new Button(this);b.setText(text);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setBackgroundColor(Color.TRANSPARENT);b.setTextSize(23);return b;}
    @Override public void onBackPressed() {if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();}
    @Override protected void onSaveInstanceState(Bundle out){web.saveState(out);super.onSaveInstanceState(out);}
    @Override protected void onPause(){super.onPause();CookieManager.getInstance().flush();}
}
